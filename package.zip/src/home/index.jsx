import { UserButton } from '@clerk/clerk-react'
// import { Button } from '../components/ui/button'
import Header from '../components/custom/Header'
import React from 'react'

function Home () {
  return (
    <div>
      <Header/>
      <UserButton />
      Landing Page
      
    </div>
  )
}

export default Home
